# BluePay Gateway Worker

نسخه آماده‌شده برای Cloudflare Worker.

## فایل‌ها

- `worker.js` فایل اصلی Worker
- `wrangler.toml` تنظیمات Cloudflare Wrangler
- `package.json` اسکریپت‌های اجرا و deploy
- `.gitignore` فایل‌های غیرضروری

## نصب سریع

ابتدا وابستگی‌ها را نصب کن:

```bash
npm install
```

اگر Wrangler لاگین نیست:

```bash
npx wrangler login
```

## ساخت دیتابیس D1

```bash
npx wrangler d1 create bluepay_gateway_db
```

بعد از اجرای دستور بالا، مقدار `database_id` را از خروجی کپی کن و داخل `wrangler.toml` جایگزین این مقدار کن:

```toml
database_id = "PUT_YOUR_D1_DATABASE_ID_HERE"
```

## تنظیم Secret ها

این موارد را با دستورهای زیر تنظیم کن:

```bash
npx wrangler secret put BOT_TOKEN
npx wrangler secret put TELEGRAM_SECRET
npx wrangler secret put ADMIN_SECRET
npx wrangler secret put BLUPAL_API_KEY
npx wrangler secret put BLUPAL_WEBHOOK_SECRET
npx wrangler secret put ADMIN_CHAT_IDS
```

اختیاری:

```bash
npx wrangler secret put DEFAULT_CARD_NUMBER
```

## Deploy

```bash
npm run deploy
```

بعد از Deploy، آدرس Worker را داخل `wrangler.toml` در مقدار `PUBLIC_URL` بگذار و دوباره Deploy بزن.

## راه‌اندازی دیتابیس و تلگرام

بعد از Deploy، این دو آدرس را باز کن:

```text
https://YOUR-WORKER.workers.dev/install?secret=ADMIN_SECRET
https://YOUR-WORKER.workers.dev/setup?secret=ADMIN_SECRET
```

## مسیرهای مهم

```text
/health
/install
/setup
/docs
/app
/api/v1/payment/create
/api/v1/payment/verify
/pay/:token
/blupal-webhook/:BLUPAL_WEBHOOK_SECRET
/telegram
```

## نکته امنیتی

هیچ‌وقت مقدارهای Secret مثل `BOT_TOKEN`، `ADMIN_SECRET`، `BLUPAL_API_KEY` و `TELEGRAM_SECRET` را داخل GitHub عمومی نگذار.
